from multiverse.server.engine import *
from multiverse.mars.plugins import *

wmgr = MarsWorldManagerPlugin()

Engine.registerPlugin(wmgr)
