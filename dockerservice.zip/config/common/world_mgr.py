from multiverse.server.engine import *

Engine.registerPlugin("multiverse.mars.plugins.MarsWorldManagerPlugin")
