from multiverse.mars.plugins import *
from multiverse.server.engine import *

#CombatClient.TEST_NAMESPACE = Namespace.intern("NS.combat_test")
