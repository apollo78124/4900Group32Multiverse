Multiverse Server README
------------------------


Multiverse Server Documentation:
http://www.multiversemmo.com/wiki/Server


Multiverse Server Installation:
http://www.multiversemmo.com/wiki/Platform_Tutorial_Getting_Started#Install_the_Multiverse_servers


Multiverse Server Forum:
http://www.multiversemmo.com/forum/viewforum.php?f=15&theme=multiverse


