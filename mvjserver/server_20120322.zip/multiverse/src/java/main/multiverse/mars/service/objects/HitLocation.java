package java.main.multiverse.mars.service.objects;

public class HitLocation {
	public String name;
	public float stunMultiplier;
	public float nStunMultiplier;
	public float bodyMultiplier;
}
