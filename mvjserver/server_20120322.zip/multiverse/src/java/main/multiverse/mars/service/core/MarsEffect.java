package java.main.multiverse.mars.service.core;

import multiverse.server.engine.*;
import multiverse.server.util.*;
import multiverse.mars.objects.*;
import multiverse.mars.plugins.CombatPlugin;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class MarsEffect {
    public MarsEffect() {
    }

    public MarsEffect(String name) {
        setName(name);
    }

    public String toString() {
        return "[MarsEffect: " + getName() + "]";
    }

    public boolean equals(Object other) {
        MarsEffect otherEffect = (MarsEffect) other;
        boolean val = getName().equals(otherEffect.getName());
        return val;
    }

    public int hashCode() {
        int hash = getName().hashCode();
        return hash;
    }

    /**
     * the name is used to refer to the effect, so use a unique name
     */
    public void setName(String name) { this.name = name; }
    public String getName() { return name; }
    String name = null;

    // add the effect to the object
    public void apply(EffectState state) {
        if (Log.loggingDebug)
            Log.debug("MarsEffect.apply: applying effect " + state.getEffectName() + " to " +
                      state.getObject());
    }

    // remove the effect from the object
    public void remove(EffectState state) {
        if (Log.loggingDebug)
            Log.debug("MarsEffect.remove: removing effect " + state.getEffectName() + " from " +
                      state.getObject());
    }

    // perform the next periodic pulse for this effect on the object
    public void pulse(EffectState state) {
        if (Log.loggingDebug)
            Log.debug("MarsEffect.pulse: pulsing effect " + state.getEffectName() + " on " + state.getObject());
    }

    public long getDuration() { return duration; }
    public void setDuration(long dur) { duration = dur; }
    protected long duration = 0;

    public int getNumPulses() { return numPulses; }
    public  void setNumPulses(int num) { this.numPulses = num; }
    protected int numPulses = 0;
    public long getPulseTime() { return (numPulses > 0) ? (duration/numPulses) : 0; }

    public void setIcon(String icon) { this.icon = icon; }
    public String getIcon() { return (icon == null) ? "UNKNOWN_ICON" : icon; }
    String icon = null;

    public boolean isPeriodic() { return periodic; }
    public void isPeriodic(boolean b) { periodic = b; }
    private boolean periodic = false;

    public boolean isPersistent() { return persistent; }
    public void isPersistent(boolean b) { persistent = b; }
    private boolean persistent = false;

    protected EffectState generateState(CombatInfo caster, CombatInfo obj, Map<String, Object> params) { //BCIT Map<String,Object>
        return new EffectState(this, caster, obj, params);
    }

    public static EffectState applyEffect(MarsEffect effect, CombatInfo caster, CombatInfo obj) {
	return applyEffect(effect, caster, obj, null);
    }

    public static EffectState applyEffect(MarsEffect effect, CombatInfo caster, CombatInfo obj, Map<String, Object> params) { //BCIT Map<String,Object>
        Lock lock = obj.getLock();
        lock.lock();
        try {
            EffectState state = effect.generateState(caster, obj, params);

            if (effect.isPeriodic() && !effect.isPersistent()) {
                throw new MVRuntimeException("MarsEffect: periodic effects must be persistent");
            }
            if (effect.isPersistent()) {
                obj.addEffect(state);
                if (effect.isPeriodic()) {
                    state.setNextPulse(0);
                    state.schedule(effect.getPulseTime());
                }
                else {
                    state.schedule(effect.getDuration());
                }
            }
            effect.apply(state);
            return state;
        }
        finally {
            lock.unlock();
        }
    }

    public static void removeEffect(MarsEffect.EffectState state) {
        Lock lock = state.getObject().getLock();
        lock.lock();
        try {
            if (!state.getEffect().isPersistent()) {
                Log.error("MarsEffect.removeEffect: tried to remove a persistent effect");
                throw new MVRuntimeException("MarsEffect.removeEffect: tried to remove a persistent effect");
            }
            state.isActive(false);
            Engine.getExecutor().remove(state);
            state.getEffect().remove(state);
            state.getObject().removeEffect(state);
        }
        finally {
            lock.unlock();
        }
    }

    public static class EffectState implements Runnable, Serializable {
        public EffectState() {
        }

        public EffectState(MarsEffect effect, CombatInfo caster, CombatInfo obj, Map<String, Object> params) { //BCIT Map<String,Object>
            this.effect = effect;
            this.effectName = effect.getName();
            this.casterOid = caster.getOid();
            this.objOid = obj.getOid();
	    this.params = params;
        }

        public void run() {
            try {
                updateState();
            }
            catch (MVRuntimeException e) {
                Log.exception("EffectState.run: got exception", e);
            }
        }

        public void updateState() {
            if (!isActive()) {
                return;
            }
            if (effect.isPeriodic()) {
                effect.pulse(this);
                nextPulse++;
                if (nextPulse < effect.getNumPulses()) {
                    schedule(effect.getPulseTime());
                    return;
                }
            }
            MarsEffect.removeEffect(this);
        }

        public void schedule(long delay) {
            setTimeRemaining(delay);
            Engine.getExecutor().schedule(this, delay, TimeUnit.MILLISECONDS);
        }

        public void resume() {
            effect = Mars.EffectManager.get(effectName);
            if (Log.loggingDebug)
                Log.debug("MarsEffect.resume: effectName=" + effectName + " effect=" + effect + " timeRemaining="
		          + getTimeRemaining());
            Engine.getExecutor().schedule(this, getTimeRemaining(), TimeUnit.MILLISECONDS);
        }

        public MarsEffect getEffect() { return effect; }
        protected transient MarsEffect effect = null;

        public String getEffectName() { return effectName; }
        public void setEffectName(String effectName) { this.effectName = effectName; }
        protected String effectName;

        public CombatInfo getObject() { return CombatPlugin.getCombatInfo(objOid); }
	public Long getObjectOid() { return objOid; }
	public void setObjectOid(Long oid) { objOid = oid; }
	protected Long objOid = null;

        public CombatInfo getCaster() { return CombatPlugin.getCombatInfo(casterOid); }
	public Long getCasterOid() { return casterOid; }
	public void setCasterOid(Long oid) { casterOid = oid; }
	protected Long casterOid = null;

        public long getNextWakeupTime() { return nextWakeupTime; }
        public long getTimeRemaining() { return nextWakeupTime - System.currentTimeMillis(); }
        public void setTimeRemaining(long time) { nextWakeupTime = System.currentTimeMillis() + time; }
        protected long nextWakeupTime;

        public int getNextPulse() { return nextPulse; }
        public void setNextPulse(int num) { nextPulse = num; }
        protected int nextPulse = 0;

        public boolean isActive() { return active; }
        public void isActive(boolean active) { this.active = active; }
        protected boolean active = true;

	public Map<String, Object> getParams() { return params; } //BCIT Map<String,Object>
	public void setParams(Map<String, Object> params) { this.params = params; } //BCIT Map<String,Object>
	protected Map<String, Object> params = null; //BCIT Map<String,Object>

        private static final long serialVersionUID = 1L;
    }
}