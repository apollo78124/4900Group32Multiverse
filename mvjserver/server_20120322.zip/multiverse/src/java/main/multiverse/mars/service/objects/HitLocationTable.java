package java.main.multiverse.mars.service.objects;

public class HitLocationTable {
	public static HitLocation getHitLocation() {
		return null;
	}
}
