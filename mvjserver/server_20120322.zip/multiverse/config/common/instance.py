from multiverse.server.plugins import *


Engine.registerPlugin(InstancePlugin())

